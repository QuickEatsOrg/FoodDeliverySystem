using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using FoodDelivery.API.Data;
using FoodDelivery.API.DTOs.Sanjana;
using FoodDelivery.API.Models;
using FoodDelivery.API.Services.Interfaces.Sanjana;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Identity;
using AutoMapper;

namespace FoodDelivery.API.Services.Implementations.Sanjana;

public class AuthService : IAuthService
{
    private readonly FoodDeliveryDbContext _context;
    private readonly IConfiguration _configuration;
    private readonly IMapper _mapper;
    private readonly IPasswordHasher<Customer> _customerPasswordHasher;
    private readonly IPasswordHasher<DeliveryDriver> _driverPasswordHasher;
    private readonly IPasswordHasher<Restaurant> _restaurantPasswordHasher;

    public AuthService(FoodDeliveryDbContext context, IConfiguration configuration, IMapper mapper, IPasswordHasher<Customer> customerPasswordHasher, IPasswordHasher<DeliveryDriver> driverPasswordHasher, IPasswordHasher<Restaurant> restaurantPasswordHasher)
    {
        _context = context;
        _configuration = configuration;
        _mapper = mapper;
        _customerPasswordHasher = customerPasswordHasher;
        _driverPasswordHasher = driverPasswordHasher;
        _restaurantPasswordHasher = restaurantPasswordHasher;
    }

    public async Task<AuthResponseDto?> LoginAsync(LoginDto loginDto)
    {
        bool isValid = false;
        string userRole = loginDto.Role;
        string userId = string.Empty;

        // Hardcoded Admin
        if (loginDto.Role == "Admin")
        {
            if (loginDto.Email == "admin@fooddelivery.com"
                && loginDto.Password == "Admin@123")
            {
                isValid = true;
                userId = "admin";
            }
        }

        else if (loginDto.Role == "Customer")
        {
            var customer = await _context.Customers
                .FirstOrDefaultAsync(c =>
                    c.CustomerEmail == loginDto.Email &&
                    c.CustomerUnhashedPassword == loginDto.Password);

            if (customer != null &&
                !string.IsNullOrEmpty(customer.CustomerHashedPassword))
            {
                var result = _customerPasswordHasher.VerifyHashedPassword(
                    customer,
                    customer.CustomerHashedPassword,
                    loginDto.Password);

                if (result == PasswordVerificationResult.Success)
                {
                    isValid = true;
                    userId = customer.CustomerId.ToString();
                }
            }
        }

        else if (loginDto.Role == "DeliveryDriver")
        {
            var driver = await _context.DeliveryDrivers
                .FirstOrDefaultAsync(d =>
                    d.DriverEmail == loginDto.Email &&
                    d.DriverUnhashedPassword == loginDto.Password);

            if (driver != null &&
                !string.IsNullOrEmpty(driver.DriverHashedPassword))
            {
                var result = _driverPasswordHasher.VerifyHashedPassword(
                    driver,
                    driver.DriverHashedPassword,
                    loginDto.Password);

                if (result == PasswordVerificationResult.Success)
                {
                    isValid = true;
                    userId = driver.DriverId.ToString();
                }
            }
        }

        else if (loginDto.Role == "Restaurant")
        {
            var restaurant = await _context.Restaurants
                .FirstOrDefaultAsync(r =>
                    r.RestaurantEmail == loginDto.Email &&
                    r.RestaurantUnhashedPassword == loginDto.Password);

            if (restaurant != null &&
                !string.IsNullOrEmpty(restaurant.RestaurantHashedPassword))
            {
                var result = _restaurantPasswordHasher.VerifyHashedPassword(
                    restaurant,
                    restaurant.RestaurantHashedPassword,
                    loginDto.Password);

                if (result == PasswordVerificationResult.Success)
                {
                    isValid = true;
                    userId = restaurant.RestaurantId.ToString();
                }
            }
        }

        if (isValid)
        {
            var token = GenerateJwtToken(loginDto.Email, userRole, userId);

            return new AuthResponseDto
            {
                Token = token,
                Email = loginDto.Email,
                Role = userRole
            };
        }

        return null;
    }
    public async Task<bool> RegisterCustomerAsync(CreateCustomerDto customerDto)
    {
        if (await _context.Customers.AnyAsync(c => c.CustomerEmail == customerDto.CustomerEmail))
            return false;

        var customer = _mapper.Map<Customer>(customerDto);

        if (!string.IsNullOrEmpty(customerDto.Password))
        {
            customer.CustomerHashedPassword = _customerPasswordHasher.HashPassword(customer, customerDto.Password);
            customer.CustomerUnhashedPassword = null;
        }

        _context.Customers.Add(customer);
        return await _context.SaveChangesAsync() > 0;

     
    }

    public async Task<bool> RegisterDriverAsync(RegisterDriverDto driverDto)
    {
        if (await _context.DeliveryDrivers.AnyAsync(d => d.DriverEmail == driverDto.DriverEmail))
            return false;

        var driver = _mapper.Map<DeliveryDriver>(driverDto);

        if (!string.IsNullOrEmpty(driverDto.Password))
        {
            driver.DriverHashedPassword = _driverPasswordHasher.HashPassword(driver, driverDto.Password);
            driver.DriverUnhashedPassword = null; 
        }

        _context.DeliveryDrivers.Add(driver);
        return await _context.SaveChangesAsync() > 0;
    }

    public async Task<bool> RegisterRestaurantAsync(RegisterRestaurantDto restaurantDto)
    {
        if (await _context.Restaurants.AnyAsync(r => r.RestaurantEmail == restaurantDto.RestaurantEmail))
            return false;

        var restaurant = _mapper.Map<Restaurant>(restaurantDto);

        if (!string.IsNullOrEmpty(restaurantDto.Password))
        {
            restaurant.RestaurantHashedPassword = _restaurantPasswordHasher.HashPassword(restaurant, restaurantDto.Password);
            restaurant.RestaurantUnhashedPassword = null;
        }

        _context.Restaurants.Add(restaurant);
        return await _context.SaveChangesAsync() > 0;
    }

    private string GenerateJwtToken(string email, string role, string userId)
    {
        var jwtSettings = _configuration.GetSection("Jwt");
        var key = Encoding.ASCII.GetBytes(jwtSettings["Key"]!);

        var tokenHandler = new JwtSecurityTokenHandler();
        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.Email, email),
                new Claim(ClaimTypes.Role, role),
                new Claim(ClaimTypes.NameIdentifier, userId)
            }),
            Expires = DateTime.UtcNow.AddDays(7),
            Issuer = jwtSettings["Issuer"],
            Audience = jwtSettings["Audience"],
            SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
        };

        var token = tokenHandler.CreateToken(tokenDescriptor);
        return tokenHandler.WriteToken(token);
    }
}

using FoodDelivery.API.DTOs.Sanjana;
using FoodDelivery.API.Services.Interfaces.Sanjana;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FoodDelivery.API.Controllers.Sanjana
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin, Customer")]
    public class AddressController : ControllerBase
    {
        private readonly IAddressService _service;
        public AddressController(IAddressService service)
        {
            _service = service;
        }

        [HttpPost("customer/{customerId}")]
        public async Task<IActionResult> CreateAddressAsync(int customerId, CreateAddressDto dto)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var userRole = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

            if (userRole == "Customer" && userId != customerId.ToString())
            {
                return Forbid();
            }

            var address = await _service.CreateAddressAsync(customerId, dto);
            return StatusCode(201, new ApiResponse<AddressResponseDto>
            {
                Success = true,
                Message = "Address created successfully",
                Data = address,
                TimeStamp = DateTime.Now
            });
        }

        [HttpGet("{addressId}")]
        public async Task<IActionResult> GetAddressByAddressIdAsync(int addressId)
        {
            var address = await _service.GetAddressByAddressIdAsync(addressId);
            
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var userRole = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

            if (userRole == "Customer" && userId != address.CustomerId.ToString())
            {
                return Forbid();
            }

            return Ok(new ApiResponse<AddressResponseDto>
            {
                Success = true,
                Message = "Address retrieved successfully",
                Data = address,
                TimeStamp = DateTime.Now
            });
        }

        [HttpGet("customer/{customerId}")]
        public async Task<IActionResult> GetAddressesByCustomerIdAsync(int customerId)
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var userRole = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

            if (userRole == "Customer" && userId != customerId.ToString())
            {
                return Forbid();
            }

            var addresses = await _service.GetAllAddressesByCustomerIdAsync(customerId);
            return Ok(new ApiResponse<IEnumerable<AddressResponseDto>>
            {
                Success = true,
                Message = "Addresses retrieved successfully",
                Data = addresses,
                TimeStamp = DateTime.Now
            });
        }

        [HttpPut("{addressId}")]
        public async Task<IActionResult> UpdateAddressAsync(int addressId, UpdateAddressDto dto)
        {
            var address = await _service.GetAddressByAddressIdAsync(addressId);

            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;
            var userRole = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;

            if (userRole == "Customer" && userId != address.CustomerId.ToString())
            {
                return Forbid();
            }

            var updatedAddress = await _service.UpdateAddressAsync(addressId, dto);
            return Ok(new ApiResponse<AddressResponseDto>
            {
                Success = true,
                Message = "Address updated successfully",
                Data = updatedAddress,
                TimeStamp = DateTime.Now
            });
        }
    }
}